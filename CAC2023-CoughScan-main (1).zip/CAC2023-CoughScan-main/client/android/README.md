# Client/Android
Android app written in kotlin to interact with diagnosis API
