# Client/Web
Website+server written in SvelteKit with typescript to interact with diagnosis API

