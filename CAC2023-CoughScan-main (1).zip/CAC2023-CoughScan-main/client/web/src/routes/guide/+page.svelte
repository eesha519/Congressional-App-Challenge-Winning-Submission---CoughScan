<link rel="stylesheet" href="/css/guide.css"/>
<main>
    <h1 class="h-font">CoughScan Guide</h1>
    <div>
        <h2>How can I use CoughScan to predict if I have COVID-19?</h2>
        <p>
            CoughScan uses a cough test to diagnose COVID-19, and it can do so with about an 85% accuracy. However, the cough test works best when sickness is a given. This means that you should be symptomatic when taking the COVID-19 test. This is where the symptoms test comes in, as while it can diagnose COVID-19, it may have trouble differentiating between sicknesses similar to COVID-19. If you aren't sure if you are symptomatic, take the symptoms test and then take the cough test.
        </p>
    </div>
    <div>
        <h2>Symptoms Test</h2>
        <p>
            The <a on:click={() => {window.location.href = "/input-symptoms"}}>symptoms test</a> is easy to use; simply answer all questions on the page to the best of your ability and press the submit button. You will be diagnosed as symptomatic or asymptomatic after taking the test.
        </p>
    </div>
    <div>
        <h2>Cough Test</h2>
        <p>
            For the <a on:click={() => {window.location.href = "/cough-test"}}>cough test</a>, you will need to cough into your microphone one time. Try to minimise background noise, and make sure to cough clearly into the microphone. You will need to allow microphone access for this website in order to complete the test. After you are done recording, you will need to complete 3 simple questions to get your prediction.
        </p>
    </div>
</main> 