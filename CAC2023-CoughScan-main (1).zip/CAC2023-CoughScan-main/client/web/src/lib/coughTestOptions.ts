export const coughTestOptionLabels = [
    ["Age group [0-9, 10-19, 20-24, 25-59, 60+]", "ageRange"],
    ["Sex [Male, Female, Other]", "sex"],
    ["Fever", "fever"]
]
